package main

import "fmt"

func main() {
	fmt.Println("This is an example.")
}
